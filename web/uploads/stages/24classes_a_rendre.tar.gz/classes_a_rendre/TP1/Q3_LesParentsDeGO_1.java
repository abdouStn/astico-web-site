import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.vocabulary.RDF;

public class Q3_LesParentsDeGO_1 {
	
	public static final String rdf_file = "Question1.rdf";
	
      public static void main( String[] args ) {
         
        Model m = ModelFactory.createDefaultModel();
       
        FileManager.get().readModel( m, rdf_file );

        String go_ns = m.getNsPrefixURI("go" );
    	
        Property go_parent = m.getProperty(go_ns+ "is_a");
        Resource go_1 = m.getResource( go_ns+ "GO_0000001" );	
    	
    	
    	
	    	NodeIterator nod_i1 = m.listObjectsOfProperty(go_1, go_parent);
	    	//NodeIterator nod_i2 = m.listObjectsOfProperty(go_instance, go_definition);
	 	    while (nod_i1.hasNext())
	 		{ 
	 	    	RDFNode n = nod_i1.nextNode(); // RDF est plus generale que ressource, prends des ressources et des litteraux
	 	    	
				Resource s = (Resource) n;
				System.out.println(go_1.getLocalName()+ " a pour parent " +s.getLocalName() ) ;
				
				//On va chercher les noms de chaque parents
				NodeIterator nod_i2 = m.listObjectsOfProperty(s, m.getProperty(go_ns+ "name"));
				
				while (nod_i2.hasNext())
		 		{ 
		 	    	RDFNode n2 = nod_i2.nextNode(); 
		 	    	
					System.out.println("\t\t nom = " +n2.toString() ) ;
					
		 		}
	 		}	 	   
	 	}
      
 }