// une autre maniere de manipuler les triplets. au lieu de faire listObjets....

import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.SimpleSelector;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.rdf.model.Statement;

public class Q6_LesNomsSelector {

    public static void main(String[] args) {
    	  Model m = ModelFactory.createDefaultModel();
		  String fil_URL = "file:Question1.rdf";
		  m.read(fil_URL);
		
		   String go_ns = m.getNsPrefixURI("go" );
        Property labelProperty = 
        m.createProperty(go_ns+"name");


        StmtIterator iter =
            m.listStatements(new SimpleSelector(null, labelProperty,(RDFNode) null));
             
        //Loop to traverse the statements that match the SimpleSelector
        while (iter.hasNext()) {
            Statement stmt = iter.nextStatement();
            Resource cpt = stmt.getSubject();
   		 String alias = cpt.getLocalName();
   		 System.out.print(" terme go avec pour alias : "+alias);
            if (stmt.getObject().isLiteral()) {
                Literal obj = (Literal) stmt.getObject();
                System.out.println(" et pour nom  " + 
                                                          obj.getString());
            }   
            else
				{ 
            	Resource s = (Resource) stmt.getObject();
	System.out.println(" Nom Qualifie : "+s.getLocalName()+" [ Espace de nommage "+s.getNameSpace()+ " ] ");
				}
        }   
    }   }