import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.vocabulary.RDF;

public class Q3_LesParents {
	
	public static final String rdf_file = "Question1.rdf";
      public static void main( String[] args ) {
         
        Model m = ModelFactory.createDefaultModel();
       
        FileManager.get().readModel( m, rdf_file );

        String go_ns = m.getNsPrefixURI("go" );
    	
        Resource go_term = m.getResource( go_ns+ "term" );	
    	Property go_parent = m.getProperty(go_ns+ "is_a");
    	
    	
    	// chercher les sujets (ressources) des triplets qui ont pour propriete type (et pr ressources go_term ?)
    	ResIterator res_i = m.listSubjectsWithProperty( RDF.type, go_term );
    	while (res_i.hasNext())
    	{ 
    		Resource go_instance = res_i.nextResource();
    	
	    	// cherche les objets qui sont liés avec notre ressource que nous avons recuperer
	    	NodeIterator nod_i1 = m.listObjectsOfProperty(go_instance, go_parent);
	    	//NodeIterator nod_i2 = m.listObjectsOfProperty(go_instance, go_definition);
	 	    while (nod_i1.hasNext())
	 		{ 
	 	    	RDFNode n = nod_i1.nextNode(); // RDF est plus generale que ressource, prends des ressources et des litteraux
	 	    	
	 			if (n.isLiteral() )
	 				System.out.println(go_instance.getLocalName()+" : " +" a pour parent " +n.toString() ) ;
	 			else 
	 			{
	 				if (n.isAnon()) // si ressource anonyme
	 				{
	 					Resource s = (Resource) n;
	 					System.out.println(go_instance+" : " +" a pour parent " +s.toString() ) ;
	 				}
	 				else 
	 				{
	 					Resource s = (Resource) n;
	 					System.out.println(go_instance.getLocalName()+ " a pour parent " +s.getURI() ) ;
	 				}
	 				
	 			}
	    	 }
	 	    
	 	   
	 	}
    	
    	
      }
 }