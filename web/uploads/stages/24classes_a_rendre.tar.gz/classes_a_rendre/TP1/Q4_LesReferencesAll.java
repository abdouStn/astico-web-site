import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.vocabulary.RDF;

public class Q4_LesReferencesAll {
	// Partie 1 afficher toutes les bdd ainsi que l'identifiant dans cette bdd
	public static final String rdf_file = "Question1.rdf";
	//public static final String rdf_file = "go_daily_mod.rdf";
	 public static void main( String[] args ) {
         
	        Model m = ModelFactory.createDefaultModel();
	       
	        FileManager.get().readModel( m, rdf_file );

	        String go_ns = m.getNsPrefixURI("go" );
	    	
	        Resource go_term = m.getResource( go_ns+ "term" );	
	        Property go_name = m.getProperty(go_ns+ "name");
	        Property go_dbxref = m.getProperty(go_ns+ "dbxref");
	        Property go_dbsymbol = m.getProperty(go_ns+ "database_symbol");
	        Property go_reference = m.getProperty(go_ns+ "reference");
	        
	    	// chercher les sujets (ressources) des triplets qui ont pour propriete type (et pr ressources go_term ?)
	    	ResIterator res_i = m.listSubjectsWithProperty( RDF.type, go_term );
	    	while (res_i.hasNext())
	    	{ 
	    		Resource go_instance = res_i.nextResource();
	    	
		    	// cherche les objets qui sont liés avec notre ressource que nous avons recuperer
		    	NodeIterator nod_i1 = m.listObjectsOfProperty(go_instance, go_name);
		 	    while (nod_i1.hasNext())
	 			{ 
		 	    	RDFNode n = nod_i1.nextNode();
		 			if (n.isLiteral())
		 			System.out.println(go_instance.getLocalName()+" : "+n.toString());
	 			}
		 	   NodeIterator nod_i2 = m.listObjectsOfProperty(go_instance, go_dbxref);
		 	   while (nod_i2.hasNext())
	 			{ 
		 	    	RDFNode r = nod_i2.nextNode();
		 			if (r.isAnon())  // pas obligé
		 			{
		 				Resource na = (Resource) r;
		 				//System.out.println(" \t ref automatique "+r.toString());
		 				
		 				NodeIterator nod_i3 = m.listObjectsOfProperty(na, go_dbsymbol);
		 				NodeIterator nod_i4 = m.listObjectsOfProperty(na, go_reference);
		 				while (nod_i3.hasNext()|| nod_i4.hasNext() )
			 			{ 
				 	    	RDFNode d = nod_i3.nextNode();
				 	    	RDFNode ref = nod_i4.nextNode();
				 	    	//Resource d1 = (Resource) d;
			 				System.out.println(" \t BD "+d.toString() + "\n\t reference : "+ ref.toString() + "\n ---" );
			 			}
			 				
		 			}
	 			}
	 		}
	    }
	}