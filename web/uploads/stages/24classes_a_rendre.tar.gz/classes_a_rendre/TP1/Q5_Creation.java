

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.sparql.vocabulary.FOAF;
import com.hp.hpl.jena.vocabulary.DC;
import com.hp.hpl.jena.vocabulary.RDF;
import com.hp.hpl.jena.vocabulary.DCTerms;
import com.hp.hpl.jena.vocabulary.XSD;

public class Q5_Creation {

	public static final String go_ns = "http://www.geneontology.org/go#";
	
	public static void main(String args[])
	{

		try {	
			 Model m = ModelFactory.createDefaultModel();
				m.setNsPrefix("go",go_ns);
		
				m.setNsPrefix("foaf",FOAF.getURI());
				m.setNsPrefix("dct",DCTerms.getURI());
				m.setNsPrefix("xsd", XSD.getURI());
				
			// la classe term de go
			 Resource term = m.createResource(go_ns+"Term");
			 Property name = m.createProperty(go_ns+"name");
			 Property definition = m.createProperty(go_ns+"definition");
			 Property is_a = m.createProperty(go_ns+"is_a");
			 
			 
			 // des individus skos:Concept
			 Resource go_OOO5524 = m.createResource(go_ns+"go_OOO5524");
			 go_OOO5524.addProperty(RDF.type, term);
			 go_OOO5524.addProperty(name, m.createLiteral("ATP binding","en"));
			 go_OOO5524.addProperty(definition, m.createLiteral("Interacting selectively and non-covalently with ATP, adenosine 5'-triphosphate, a universally important coenzyme and enzyme regulator.","en"));
			
			 Resource go_OOO0037 = m.createResource(go_ns+"go_OOO0037");
			 go_OOO0037.addProperty(RDF.type, term);
			 go_OOO5524.addProperty(is_a, go_OOO0037);
			 // afficher les triplets ainsi definis
			 m.write(System.out, "N3");
		    	
	    	 try {       
		    	  FileOutputStream outStream = new FileOutputStream("go_test.rdf");//format xml
		             // exporte le resultat dans un fichier
		             m.write(outStream, "RDF/XML");
		             outStream.close();
		             
		           FileOutputStream outStream1 = new FileOutputStream("go_test.n3"); // format plus lisible
		             m.write(outStream1, "N3");
		             outStream1.close();
	    	 }
		      catch (FileNotFoundException e) {System.out.println("File not found");}
		      catch (IOException e) {System.out.println("IO problem");}
			 
		}
		catch (Exception e)
		{System.out.println("failure"+e);}
	} 
	
}