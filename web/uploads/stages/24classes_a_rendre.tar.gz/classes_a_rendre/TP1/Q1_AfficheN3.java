import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.util.FileManager;


public class Q1_AfficheN3 {
	public static final String go_ns = "http://www.geneontology.org/go#"; // espace de nom de la geneOntology qui contient tout son vocabulaire
	public static final String rdf_file = "Question1.rdf";
      public static void main( String[] args ) {
         //on charge le contenu du fichier dans le modele m
        Model m = ModelFactory.createDefaultModel();
		m.setNsPrefix("go",go_ns);
        FileManager.get().readModel( m, rdf_file );
        
   	    m.write(System.out, "N3");
   	 
      }
}