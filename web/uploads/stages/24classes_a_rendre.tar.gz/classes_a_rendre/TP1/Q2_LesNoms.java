import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.vocabulary.RDF;

public class Q2_LesNoms {
	
	public static final String rdf_file = "Question1.rdf";
      public static void main( String[] args ) {
         
        Model m = ModelFactory.createDefaultModel();
       
        FileManager.get().readModel( m, rdf_file );

        String go_ns = m.getNsPrefixURI("go" );
    	
        Resource go_term = m.getResource( go_ns+ "term" );	
    	Property go_name = m.getProperty(go_ns+ "name"); 	
    	
    	// chercher les sujets (ressources) des triplets qui ont pour propriete type (et pr ressources go_term ?)
    	ResIterator res_i = m.listSubjectsWithProperty( RDF.type, go_term );
    	while (res_i.hasNext())
    	{ Resource go_instance = res_i.nextResource();
    	
    	// cherche les objets qui sont liés avec notre ressource que nous avons recuperer
    	NodeIterator nod_i1 = m.listObjectsOfProperty(go_instance, go_name);
 	    while (nod_i1.hasNext())
 			{ RDFNode n = nod_i1.nextNode();
 			if (n.isLiteral())
 			System.out.println(go_instance.getLocalName()+" : "+n.toString());
    	}
 			}
    	
    	
      }}