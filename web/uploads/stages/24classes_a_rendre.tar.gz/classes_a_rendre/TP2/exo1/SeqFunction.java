package exo1;

public class SeqFunction {
	private String name;
	private String Catalytic_activity;
	private String Enzyme_regulation;
	// ...
	public SeqFunction(String name, String catalytic_activity,
			String enzyme_regulation) {
		super();
		this.name = name;
		Catalytic_activity = catalytic_activity;
		Enzyme_regulation = enzyme_regulation;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCatalytic_activity() {
		return Catalytic_activity;
	}
	public void setCatalytic_activity(String catalytic_activity) {
		Catalytic_activity = catalytic_activity;
	}
	public String getEnzyme_regulation() {
		return Enzyme_regulation;
	}
	public void setEnzyme_regulation(String enzyme_regulation) {
		Enzyme_regulation = enzyme_regulation;
	}
	
	

}
