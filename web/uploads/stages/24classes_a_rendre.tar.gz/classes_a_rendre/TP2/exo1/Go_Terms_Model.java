package exo1;

import java.util.ArrayList;

import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.vocabulary.RDF;

public class Go_Terms_Model {

	private Model m = ModelFactory.createDefaultModel();
	private String go_ns = m.getNsPrefixURI("go"); // namespace

	public Go_Terms_Model(Model m) 
	{
		this.m = m;
	}

	public Model getModel() 
	{
		return m;
	}

	public void setModel(Model m) 
	{
		this.m = m;
	}

	public String get_Go_Ns() 
	{
		return go_ns;
	}

	public void set_Go_Ns(String go_ns) 
	{
		this.go_ns = m.getNsPrefixURI(go_ns);
	}

	public String get_Go_Term_Name(String go_term) 
	{
		String go_t_name = " vide ";
		Resource go_t = m.getResource(go_ns + go_term);
		Property go_name = m.getProperty(go_ns + "name");
		NodeIterator nod_i1 = m.listObjectsOfProperty(go_t, go_name);
		while (nod_i1.hasNext()) 
		{
			RDFNode n = nod_i1.nextNode();
			if (n.isLiteral())
				System.out.println(go_t.getLocalName() + " " + n.toString());
			go_t_name = n.toString();
		}
		return go_t_name;
	}
	
	public void afficherParents()
	{
		Resource go_term = m.getResource( go_ns+ "term" );	
    	Property go_parent = m.getProperty(go_ns+ "is_a");
    	
    	ResIterator res_i = m.listSubjectsWithProperty( RDF.type, go_term );
    	while (res_i.hasNext())
    	{ 
    		Resource go_instance = res_i.nextResource();
    	
	    	// cherche les objets qui sont liés avec notre ressource que nous avons recuperer
	    	NodeIterator nod_i1 = m.listObjectsOfProperty(go_instance, go_parent);
	    	//NodeIterator nod_i2 = m.listObjectsOfProperty(go_instance, go_definition);
	 	    while (nod_i1.hasNext())
	 		{ 
	 	    	RDFNode n = nod_i1.nextNode(); // RDF est plus generale que ressource, prends des ressources et des litteraux
	 	    	
	 			if (n.isLiteral() )
	 				System.out.println(go_instance.getLocalName()+" : " +" a pour parent " +n.toString() ) ;
	 			else 
	 			{
	 				if (n.isAnon()) // si ressource anonyme
	 				{
	 					Resource s = (Resource) n;
	 					System.out.println(go_instance+" : " +" a pour parent " +s.toString() ) ;
	 				}
	 				else 
	 				{
	 					Resource s = (Resource) n;
	 					System.out.println(go_instance.getLocalName()+ " a pour parent " +s.getURI() ) ;
	 				}
	 			 }
	    	 }
	 	}
	}
	
	public void lesDefinitions() 
	{
		//Model m = ModelFactory.createDefaultModel();
	       
        //FileManager.get().readModel( m, rdf_file );

        //String go_ns = m.getNsPrefixURI("go" );
    	
        Resource go_term = m.getResource( go_ns+ "term" );	
    	Property go_name = m.getProperty(go_ns+ "name");
    	Property go_definition = m.getProperty(go_ns+ "definition");
    	//Property go_synonyme = m.getProperty(go_ns+ "synonym");
    	
    	// chercher les sujets (ressources) des triplets qui ont pour propriete type (et pr ressources go_term ?)
    	ResIterator res_i = m.listSubjectsWithProperty( RDF.type, go_term );
    	while (res_i.hasNext())
    	{ 
    		Resource go_instance = res_i.nextResource();
    	
	    	// cherche les objets qui sont liés avec notre ressource que nous avons recuperer
	    	NodeIterator nod_i1 = m.listObjectsOfProperty(go_instance, go_name);
	    	NodeIterator nod_i2 = m.listObjectsOfProperty(go_instance, go_definition);
	 	    while (nod_i1.hasNext())
	 		{ 
	 	    	RDFNode n = nod_i1.nextNode();
	 	    	
	 			if (n.isLiteral() )
	 				System.out.println(go_instance.getLocalName()+" : " +"NAME -> " +n.toString() ) ;
	    	}
	 	    
	 	   while (nod_i2.hasNext())
	 		{ 
	 	    	
	 	    	RDFNode d = nod_i2.nextNode();
	 			if (d.isLiteral())
	 				System.out.println(  "\t\t DEFINITON -> "	+ d.toString() + "\n");
	    	}
	 	}

	}
	
	public Go_Term construireGo_Term(String gt)   // renvoie un objet goTerm donné
	{
		Go_Term g = new Go_Term(gt);
		
		Property go_parent = m.getProperty(go_ns+ "is_a");
		Property go_name = m.getProperty(go_ns+ "name");
    	Property go_definition = m.getProperty(go_ns+ "definition");
    			
		Resource go_1 = m.getResource( go_ns+ gt );
		
		NodeIterator nod_name = m.listObjectsOfProperty(go_1, go_name);
    	NodeIterator nod_def = m.listObjectsOfProperty(go_1, go_definition);
    	NodeIterator nod_parents = m.listObjectsOfProperty(go_1, go_parent);
 	    
    	while (nod_name.hasNext())
 		{ 
 	    	RDFNode n = nod_name.nextNode();
 	    	
 			if (n.isLiteral() )
 			{
 				//System.out.println(go_1.getLocalName()+" :" +"\tNAME -> " +n.toString() ) ;
 				g.setName(n.toString());
 			}
 				
    	}
 	    
 	   while (nod_def.hasNext())
 		{ 
 	    	
 	    	RDFNode d = nod_def.nextNode();
 			if (d.isLiteral())
 			{
 				//System.out.println(  "\t\tDEFINITON -> "	+ d.toString() + "\n");
 				g.setDefinition(d.toString());
 			}
    	}
		
 	    ArrayList<Go_Term> parents = new ArrayList<Go_Term>();
 	    while (nod_parents.hasNext())
 		{ 
 	    	
 	    	RDFNode n = nod_parents.nextNode(); // RDF est plus generale que ressource, prends des ressources et des litteraux
 	    	
			Resource s = (Resource) n;
			//System.out.print("\t\tParents: " +s.getLocalName() ) ;
			
			Go_Term p = new Go_Term(s.getLocalName());
			
			//On va chercher les noms de chaque parents
			NodeIterator nod_i2 = m.listObjectsOfProperty(s, m.getProperty(go_ns+ "name"));
			
			while (nod_i2.hasNext())
	 		{ 
	 	    	RDFNode n2 = nod_i2.nextNode(); 
	 	    	
				//System.out.print("\t\t -> nom = " +n2.toString() ) ;
				
				p.setName(n2.toString());
				
	 		}
			parents.add(p);
			//System.out.println();
 		}
 	    g.setParents(parents);
 	    return g;
	}

}