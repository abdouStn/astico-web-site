package exo1;

import java.util.ArrayList;

public class SeqFamilyAndDomains {
	private String sequence_similarities;
	private ArrayList<String> phylogenomic_databases;
	private ArrayList<String> family_and_domain_databases;
	
	public SeqFamilyAndDomains(String sequence_similarities) {
		super();
		this.sequence_similarities = sequence_similarities;
		this.phylogenomic_databases = new ArrayList<String>();
		this.family_and_domain_databases = new ArrayList<String>();
	}
	
	public SeqFamilyAndDomains(String sequence_similarities,
			ArrayList<String> phylogenomic_databases,
			ArrayList<String> family_and_domain_databases) {
		super();
		this.sequence_similarities = sequence_similarities;
		this.phylogenomic_databases = phylogenomic_databases;
		this.family_and_domain_databases = family_and_domain_databases;
	}

	public String getSequence_similarities() {
		return sequence_similarities;
	}

	public void setSequence_similarities(String sequence_similarities) {
		this.sequence_similarities = sequence_similarities;
	}

	public ArrayList<String> getPhylogenomic_databases() {
		return phylogenomic_databases;
	}

	public void setPhylogenomic_databases(ArrayList<String> phylogenomic_databases) {
		this.phylogenomic_databases = phylogenomic_databases;
	}

	public ArrayList<String> getFamily_and_domain_databases() {
		return family_and_domain_databases;
	}

	public void setFamily_and_domain_databases(
			ArrayList<String> family_and_domain_databases) {
		this.family_and_domain_databases = family_and_domain_databases;
	}
	
	
	
}
