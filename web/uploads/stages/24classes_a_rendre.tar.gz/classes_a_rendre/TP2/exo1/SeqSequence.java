package exo1;

public class SeqSequence {
	private String sequence_status; 
	private String sequence_processing;
	private String sequence;
	//...
	public SeqSequence(String sequence_status, String sequence_processing,
			String sequence) {
		super();
		this.sequence_status = sequence_status;
		this.sequence_processing = sequence_processing;
		this.sequence = sequence;
	}
	public String getSequence_status() {
		return sequence_status;
	}
	public void setSequence_status(String sequence_status) {
		this.sequence_status = sequence_status;
	}
	public String getSequence_processing() {
		return sequence_processing;
	}
	public void setSequence_processing(String sequence_processing) {
		this.sequence_processing = sequence_processing;
	}
	public String getSequence() {
		return sequence;
	}
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	
	
	
}
