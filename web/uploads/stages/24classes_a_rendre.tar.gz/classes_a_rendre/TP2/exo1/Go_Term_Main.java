package exo1;

import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.vocabulary.RDF;

public class Go_Term_Main {

	public static final String rdf_file = "Question1.rdf";

	public static void main(String[] args) {

		Model m = ModelFactory.createDefaultModel();

		FileManager.get().readModel(m, rdf_file);
		// String go_ns = m.getNsPrefixURI("go" );
		System.out.println("Nombre de triplets  = " + m.size());
		Go_Terms_Model gtm = new Go_Terms_Model(m);
		gtm.set_Go_Ns("go");
		
		//System.out.println("test " + gtm.get_Go_Ns());
		//System.out.println("test " + gtm.get_Go_Term_Name("GO_0000001"));
		
		System.out.println("---------------- Methode construireGo_Term ----------------------"); 
		Go_Term g = gtm.construireGo_Term("GO_0000001");  // construit un Objet Go_Term a partir d'un id
		System.out.println(g.toString());
		
		System.out.println("---------------- Methode afficherParents()----------------------");
		gtm.afficherParents();
		
		System.out.println("---------------- Methode lesDefinitions()----------------------");
		gtm.lesDefinitions();
		
		
	}

}