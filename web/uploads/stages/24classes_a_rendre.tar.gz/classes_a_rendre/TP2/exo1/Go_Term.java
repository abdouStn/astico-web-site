package exo1;
import java.util.List;
import java.util.ArrayList;

public class Go_Term
{
    private String go_id;
    private String name;
    private String definition;
    private ArrayList<Go_Term> parents; 
    private String synonyme;
    private String commentaire;
    private ArrayList<ReferenceBdd> refsBdd ;
    
    
    public Go_Term(String go_id)
    {
    	this.go_id = go_id; 
    }
    
    public Go_Term(String go_id, String name, String definition, String synonyme, String commentaire)
    {
        this.go_id = go_id;
        this.name = name;
        this.definition = definition;
        this.synonyme = synonyme;
        this.commentaire = commentaire;
        
        refsBdd = new ArrayList<ReferenceBdd>();
        parents = new ArrayList<Go_Term>();
    }

    public String getGo_id() {
		return go_id;
	}

	public void setGo_id(String go_id) {
		this.go_id = go_id;
	}

	public String getSynonyme() {
		return synonyme;
	}

	public void setSynonyme(String synonyme) {
		this.synonyme = synonyme;
	}

	public String getCommentaire() {
		return commentaire;
	}

	public void setCommentaire(String commentaire) {
		this.commentaire = commentaire;
	}

	public ArrayList<ReferenceBdd> getRefsBdd() {
		return refsBdd;
	}

	public void setRefsBdd(ArrayList<ReferenceBdd> refsBdd) {
		this.refsBdd = refsBdd;
	}

	public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name=name;
    } 
    
    public String getGo_Id()
    {
        return go_id;
    }

    public void setGo_Id(String go_id)
    {
        this.go_id=go_id;
    }
    
    public String getDefinition()
    {
        return definition;
    }
    
    public void setDefinition(String definition)
    {
        this.definition=definition;
    }
    
    public List<Go_Term> getParents()
    {
            return parents;
    }

    public void setParents(ArrayList<Go_Term> parents) 
    {
                this.parents = parents;
    }

	@Override
	public String toString() {
		return "Go_Term [go_id=" + go_id + ", name=" + name + ", definition="
				+ definition + ", parents=" + parents + "]";
	}
    
}