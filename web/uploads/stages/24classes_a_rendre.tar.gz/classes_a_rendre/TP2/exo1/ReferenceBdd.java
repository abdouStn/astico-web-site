package exo1;

import java.util.ArrayList;

public class ReferenceBdd {
	private String name;
	private ArrayList<String> liens;
	
	public ReferenceBdd(String name) {
		super();
		this.name = name;
		this.liens = new ArrayList<String>();
	}
	
	public ReferenceBdd(String name, ArrayList<String> liens) {
		super();
		this.name = name;
		this.liens = liens;
	}

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ArrayList<String> getLiens() {
		return liens;
	}
	public void setLiens(ArrayList<String> liens) {
		this.liens = liens;
	}
	
	
	
	
}
