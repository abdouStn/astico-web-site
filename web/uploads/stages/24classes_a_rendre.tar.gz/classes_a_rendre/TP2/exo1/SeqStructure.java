package exo1;

import java.util.ArrayList;

public class SeqStructure {
	private ArrayList<String> structure_databases_3D;

	public SeqStructure() {
		super();
		this.structure_databases_3D = new ArrayList<String>();
	}
	
	public SeqStructure(ArrayList<String> structure_databases_3D) {
		super();
		this.structure_databases_3D = structure_databases_3D;
	}
	
	
}
