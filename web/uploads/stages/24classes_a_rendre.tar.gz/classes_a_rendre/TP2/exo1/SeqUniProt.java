package exo1;

import java.util.ArrayList;

public class SeqUniProt 
{
	private String id;
	private String name;
	private String gene;
	private String organisme;	
	private ArrayList<Go_Term> classifiedWith = new ArrayList<Go_Term>();
	
	private SeqFunction function;
	private SeqSequence sequence;
	private SeqFamilyAndDomains family_and_domains;
	private SeqStructure structure;
	//...
	
	public SeqUniProt(String id, String name, String gene, String organisme) 
	{
		super();
		this.id = id;
		this.name = name;
		this.gene = gene;
		this.organisme = organisme;
		
		this.classifiedWith = new ArrayList<Go_Term>();
		
		
	}
	
	public SeqFunction getFunction() {
		return function;
	}

	public void setFunction(SeqFunction function) {
		this.function = function;
	}

	public SeqSequence getSequence() {
		return sequence;
	}

	public void setSequence(SeqSequence sequence) {
		this.sequence = sequence;
	}

	public SeqFamilyAndDomains getFamily_and_domains() {
		return family_and_domains;
	}

	public void setFamily_and_domains(SeqFamilyAndDomains family_and_domains) {
		this.family_and_domains = family_and_domains;
	}

	public SeqStructure getStructure() {
		return structure;
	}

	public void setStructure(SeqStructure structure) {
		this.structure = structure;
	}

	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public ArrayList<Go_Term> getClassifiedWith() {
		return classifiedWith;
	}

	public void setClassifiedWith(ArrayList<Go_Term> classifiedWith) {
		this.classifiedWith = classifiedWith;
	}

	public String getGene() {
		return gene;
	}
	
	public void setGene(String gene) {
		this.gene = gene;
	}
	
	public String getOrganisme() {
		return organisme;
	}
	
	public void setOrganisme(String organisme) {
		this.organisme = organisme;
	}
	


	
	
	@Override
	public String toString() {
		return "SeqUniProt [id=" + id + ", name=" + name + ", gene=" + gene
				+ ", organisme=" + organisme + ", function=" + function + "]";
	}
	
	
	
}
