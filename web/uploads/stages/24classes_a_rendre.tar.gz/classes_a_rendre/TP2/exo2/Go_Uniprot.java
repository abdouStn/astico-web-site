package exo2;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.SimpleSelector;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.rdf.model.Statement;

public class Go_Uniprot {

	public static void main(String[] args) {
		FileManager fManager = FileManager.get();
		fManager.addLocatorURL();
		Model model = fManager
				.loadModel("http://www.uniprot.org/uniprot/P61221.rdf");
		Property coreProperty = model.createProperty(
				"http://purl.uniprot.org/core/", "classifiedWith");
		
		Property coreProperty2 = model.createProperty(
				"http://purl.uniprot.org/core/", "rdf:Description");
		
		StmtIterator iter = model.listStatements(new SimpleSelector(null,
				coreProperty2, (RDFNode) null));
		// Loop to traverse the statements that match the SimpleSelector
		while (iter.hasNext()) {
			Statement stmt = iter.nextStatement();
			if (stmt.getObject().isLiteral()) {
				Literal obj = (Literal) stmt.getObject();
				System.out.println("The term value is " + obj.getString());
			} else {
				Resource s = (Resource) stmt.getObject();
				System.out.println(" Nom Qualifie : " + s.getLocalName()
						+ " [ Espace de nommage " + s.getNameSpace() + " ] ");
			}
		}
	}
}

/*
 * Notes on Linked Data curl -L -H 'Accept: application/rdf+xml'
 * http://www.uniprot.org/uniprot/P61221.rdf curl -L -H 'Accept: application/n3'
 * http://www.uniprot.org/uniprot/P61221.rdf
 * 
 * Prefix up: <http://purl.uniprot.org/core/> select distinct ?c1 ?c2 {?c1
 * up:classifiedWith ?c2 }
 * -----
 * PREFIX up:<http://purl.uniprot.org/core/> 
 * PREFIX uniprotkb:<http://purl.uniprot.org/uniprot/> 
 * PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#> 
 * rdfs:<http://www.w3.org/2000/01/rdf-schema#> 
 * PREFIX owl:<http://www.w3.org/2002/07/owl#> 
 * PREFIX xsd:<http://www.w3.org/2001/XMLSchema#> 
 * 
 * select distinct ?c2 {uniprotkb:P61221 up:classifiedWith ?c2}
 */