package exo2;


import java.util.Iterator;

import com.hp.hpl.jena.sparql.core.ResultBinding;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.vocabulary.OWL;
import com.hp.hpl.jena.vocabulary.RDF;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.query.ResultSetFormatter;

public class Go_Ex1_Construct {

	public static final String NL = System.getProperty("line.separator");

	public static void main(String[] args) {
		Model m = ModelFactory.createOntologyModel();
		String fil_URL = "file:Question1.rdf";
		String go = "http://www.geneontology.org/go#";
		String prolog1 = "PREFIX rdf: <" + RDF.getURI() + ">";
		String prolog2 = "PREFIX go: <" + go + ">";

		m.read(fil_URL);
		// Query string.
		String rdq = prolog1
				+ NL
				+ prolog2
				+ NL
				+ "CONSTRUCT { ?term go:name ?name } WHERE {?term  go:name  ?name }";

		Query query = QueryFactory.create(rdq);
		QueryExecution qexec = QueryExecutionFactory.create(query, m);
		Model results = qexec.execConstruct();
		results.write(System.out, "N3");
		qexec.close();
	}
}