//alternatif chercher de l'info a distance que que tout charger en memoire
package exo2;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.rdf.model.RDFNode;

public class Go_UniprotEndPoint {

	public static void main(String[] args) {

		String service_ep = "http://sparql.uniprot.org/"; // gestionnaire de triplets (triple store). base de donnees
		
		/*
		 String query = "Prefix up:    <http://purl.uniprot.org/core/> "
				   + " select distinct  ?c1 ?c2 {?c1 up:classifiedWith ?c2 }   ";

		  QueryExecution qe = QueryExecutionFactory.sparqlService(service_ep,
				query);
		
		for (ResultSet rs = qe.execSelect(); rs.hasNext();) {
			QuerySolution sol = rs.nextSolution();
			RDFNode c1 = sol.get("?c1");
			RDFNode c2 = sol.get("?c2");
			System.out.println(c1 + "     " c2);
		} 
		
		
		 */
		
		// Pour trouver l'identifiant du gène GYS1_HUMAN:
		String query2 = "Prefix up:    <http://purl.uniprot.org/core/> "
				   + " select distinct  ?c1  {?c1 up:mnemonic \"GYS1_HUMAN\" }   ";
		
		// Les 10 premieres sequences, le nom du gène codant et le taxon d’origine
		String query3 = "Prefix up:    <http://purl.uniprot.org/core/> "
				   + " select distinct  ?c1 ?c2 {?c1 up:mnemonic ?c2   }   " + "LIMIT 10";

		QueryExecution qe1 = QueryExecutionFactory.sparqlService(service_ep,
				query2);
		QueryExecution qe2 = QueryExecutionFactory.sparqlService(service_ep,
				query3);
		
		for (ResultSet rs = qe1.execSelect(); rs.hasNext();) {
			QuerySolution sol = rs.nextSolution();
			RDFNode c1 = sol.get("?c1");
			
			System.out.println("---------------\nTaxonId de la séquence du gène GYS1_HUMAN:");
			System.out.println(c1);
		}
		
		System.out.println("-------------------\n10 premières séquences, TaxonId et nom de gènes:");
		for (ResultSet rs = qe2.execSelect(); rs.hasNext();) {
			QuerySolution sol = rs.nextSolution();
			RDFNode c1 = sol.get("?c1");
			RDFNode c2 = sol.get("?c2");
			
			System.out.println(c1 + "     " + c2);
		}

	}
	//on peut avoir le meme resultat sur le site de  uniprot section sparql : http://sparql.uniprot.org/
	// copier coller la requete
}